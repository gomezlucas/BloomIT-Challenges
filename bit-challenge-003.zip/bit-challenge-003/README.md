# Bloomit Digital Academy  - BitChallenge 003 (CSS) - Central Perk

[My live version](https://gomezlucas.github.io/Bloomit-Challenges/bit-challenge-003/) 

![Design preview for the challenge](./design.png)

Solution using HTML and CSS
